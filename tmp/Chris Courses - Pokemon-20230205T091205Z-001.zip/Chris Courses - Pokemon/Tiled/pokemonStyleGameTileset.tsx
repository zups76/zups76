<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="sceneSpriteSheet" tilewidth="12" tileheight="12" tilecount="1024" columns="32">
 <image source="tileset.png" width="384" height="384"/>
</tileset>
